-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Янв 09 2016 г., 12:53
-- Версия сервера: 5.6.26-74.0-beget-log
-- Версия PHP: 5.6.16

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `fb3809sd_lentrss`
--

-- --------------------------------------------------------

--
-- Структура таблицы `error_log`
--
-- Создание: Дек 28 2015 г., 18:54
--

DROP TABLE IF EXISTS `error_log`;
CREATE TABLE `error_log` (
  `id` int(11) NOT NULL,
  `text` text NOT NULL,
  `link` text NOT NULL,
  `date` datetime NOT NULL,
  `rang` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `error_log`
--

INSERT INTO `error_log` (`id`, `text`, `link`, `date`, `rang`) VALUES
(1, 'Старт парсера. Найдено 1 лент для обновления<br>Парсим http://gazeta.ua/rss <br>Добавленно 50 новых новостей<br>Конец парсинга<br>', '/rss/edit/', '2016-01-09 12:31:00', 0),
(2, 'Старт парсера. Найдено 2 лент для обновления<br>Парсим http://gazeta.ua/rss <br>Добавленно 1 новых новостей<br>Парсим http://tsn.ua/rss <br>Добавленно 40 новых новостей<br>Конец парсинга<br>', '/rss/edit/', '2016-01-09 12:50:41', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `keywords`
--
-- Создание: Дек 14 2015 г., 11:16
--

DROP TABLE IF EXISTS `keywords`;
CREATE TABLE `keywords` (
  `id` int(11) NOT NULL,
  `id_rss` int(11) NOT NULL,
  `word` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `keywords`
--

INSERT INTO `keywords` (`id`, `id_rss`, `word`) VALUES
(10, 3, 'test');

-- --------------------------------------------------------

--
-- Структура таблицы `rss`
--
-- Создание: Дек 25 2015 г., 10:18
--

DROP TABLE IF EXISTS `rss`;
CREATE TABLE `rss` (
  `id` int(11) NOT NULL,
  `title` varchar(225) NOT NULL,
  `link` varchar(255) NOT NULL,
  `description` varchar(225) NOT NULL,
  `tag` text NOT NULL,
  `period` int(11) NOT NULL,
  `update` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `rss`
--

INSERT INTO `rss` (`id`, `title`, `link`, `description`, `tag`, `period`, `update`, `date`) VALUES
(3, 'test', 'test', 'tes', 'test', 1, 0, '2016-01-09 12:48:14');

-- --------------------------------------------------------

--
-- Структура таблицы `rss_item`
--
-- Создание: Дек 25 2015 г., 11:13
-- Последнее обновление: Янв 09 2016 г., 09:51
--

DROP TABLE IF EXISTS `rss_item`;
CREATE TABLE `rss_item` (
  `id` int(11) NOT NULL,
  `id_rss` int(11) NOT NULL,
  `id_rss_parser` int(11) NOT NULL,
  `guid` varchar(255) NOT NULL,
  `title` text NOT NULL,
  `description` text NOT NULL,
  `link` text NOT NULL,
  `img` text NOT NULL,
  `period` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `special` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `rss_item`
--

INSERT INTO `rss_item` (`id`, `id_rss`, `id_rss_parser`, `guid`, `title`, `description`, `link`, `img`, `period`, `date`, `special`) VALUES
(3657, 3, 12, 'http://gazeta.ua/articles/np/_v-ukravtodori-zapevnyayut-scho-proyihati-ukrayinskimi-dorogami-mozhlivo/670375', 'В Укравтодорі запевняють, що проїхати українськими дорогами можливо', 'Gazeta.ua - 2016-01-08 17:12:54', 'http://gazeta.ua/articles/np/_v-ukravtodori-zapevnyayut-scho-proyihati-ukrayinskimi-dorogami-mozhlivo/670375', '/images/2016-01-09/1452331855_380.jpg', 0, '2016-01-08 17:12:54', 0),
(3658, 3, 12, 'http://gazeta.ua/articles/sport/_u-finali-kubka-hopmana-ukrayina-zigraye-z-avstraliyeyu/670279', 'У фіналі Кубка Хопмана Україна зіграє з Австралією', 'Gazeta.ua - 2016-01-08 17:10:59', 'http://gazeta.ua/articles/sport/_u-finali-kubka-hopmana-ukrayina-zigraye-z-avstraliyeyu/670279', '/images/2016-01-09/1452331855_778.jpg', 0, '2016-01-08 17:10:59', 0),
(3659, 3, 12, 'http://gazeta.ua/articles/science/_kitajci-vinajshli-pershe-v-sviti-bezpilotne-taksi/670374', 'Китайці винайшли перше в світі безпілотне таксі', 'Gazeta.ua - 2016-01-08 17:06:19', 'http://gazeta.ua/articles/science/_kitajci-vinajshli-pershe-v-sviti-bezpilotne-taksi/670374', '/images/2016-01-09/1452331856_298.jpg', 0, '2016-01-08 17:06:19', 0),
(3660, 3, 12, 'http://gazeta.ua/articles/sport/_biatlon-rupolding-dzhima-ta-pidgrushna-zavershili-sprint-u-pershij-desyatci/670373', 'Біатлон. Рупольдинг. Джима та Підгрушна завершили спринт у першій десятці', 'Gazeta.ua - 2016-01-08 16:59:54', 'http://gazeta.ua/articles/sport/_biatlon-rupolding-dzhima-ta-pidgrushna-zavershili-sprint-u-pershij-desyatci/670373', '/images/2016-01-09/1452331856_1192.jpg', 0, '2016-01-08 16:59:54', 0),
(3661, 3, 12, 'http://gazeta.ua/articles/life/_na-kordoni-z-norvegiyeyu-rozbivsya-shvedskij-poshtovij-litak/670368', 'На кордоні з Норвегією розбився шведський поштовий літак', 'Gazeta.ua - 2016-01-08 16:43:35', 'http://gazeta.ua/articles/life/_na-kordoni-z-norvegiyeyu-rozbivsya-shvedskij-poshtovij-litak/670368', '/images/2016-01-09/1452331856_160.jpg', 0, '2016-01-08 16:43:35', 0),
(3662, 3, 12, 'http://gazeta.ua/articles/sport/_rosiyu-ne-dopustyat-do-uchasti-v-chempionati-svitu-zi-sportivnoyi-hodbi/670372', 'Росію не допустять до участі в чемпіонаті світу зі спортивної ходьби', 'Gazeta.ua - 2016-01-08 16:28:52', 'http://gazeta.ua/articles/sport/_rosiyu-ne-dopustyat-do-uchasti-v-chempionati-svitu-zi-sportivnoyi-hodbi/670372', '/images/2016-01-09/1452331857_26.jpg', 0, '2016-01-08 16:28:52', 0),
(3663, 3, 12, 'http://gazeta.ua/articles/regions/_perevibori-v-krivomu-rozi-mozhut-mati-skladni-naslidki-berezovec/670371', '"Перевибори в Кривому Розі можуть мати складні наслідки" - Березовець', 'Gazeta.ua - 2016-01-08 16:20:31', 'http://gazeta.ua/articles/regions/_perevibori-v-krivomu-rozi-mozhut-mati-skladni-naslidki-berezovec/670371', '/images/2016-01-09/1452331857_1690.jpg', 0, '2016-01-08 16:20:31', 0),
(3648, 3, 12, 'http://gazeta.ua/articles/sport/_tenis-marchenko-ne-zumiv-stvoriti-divo-proti-nadalya-v-dosi/670385', 'Теніс. Марченко не зумів створити диво проти Надаля в Досі', 'Gazeta.ua - 2016-01-08 19:29:51', 'http://gazeta.ua/articles/sport/_tenis-marchenko-ne-zumiv-stvoriti-divo-proti-nadalya-v-dosi/670385', '/images/2016-01-09/1452331851_105.jpg', 0, '2016-01-08 19:29:51', 0),
(3649, 3, 12, 'http://gazeta.ua/articles/kiev-life/_sogodni-u-kiyevi-snig-pribirali-263-odinici-tehniki-kmda/670383', 'Сьогодні у Києві сніг прибирали 263 одиниці техніки - КМДА', 'Gazeta.ua - 2016-01-08 19:08:39', 'http://gazeta.ua/articles/kiev-life/_sogodni-u-kiyevi-snig-pribirali-263-odinici-tehniki-kmda/670383', '/images/2016-01-09/1452331852_1756.jpg', 0, '2016-01-08 19:08:39', 0),
(3650, 3, 12, 'http://gazeta.ua/articles/life/_acenyuk-doruchiv-stvoriti-interaktivnu-kartu-situaciyi-na-dorogah/670382', 'Яценюк доручив створити інтерактивну карту ситуації на дорогах', 'Gazeta.ua - 2016-01-08 18:47:31', 'http://gazeta.ua/articles/life/_acenyuk-doruchiv-stvoriti-interaktivnu-kartu-situaciyi-na-dorogah/670382', '/images/2016-01-09/1452331852_1182.jpg', 0, '2016-01-08 18:47:31', 0),
(3651, 3, 12, 'http://gazeta.ua/articles/regions/_u-dtp-na-rivnenschini-postrazhdali-devyat-osib/670381', 'У ДТП на Рівненщині постраждали дев''ять осіб', 'Gazeta.ua - 2016-01-08 18:23:34', 'http://gazeta.ua/articles/regions/_u-dtp-na-rivnenschini-postrazhdali-devyat-osib/670381', '/images/2016-01-09/1452331852_748.jpg', 0, '2016-01-08 18:23:34', 0),
(3652, 3, 12, 'http://gazeta.ua/articles/life/_finnair-nazvali-najbezpechnishoyu-aviakompaniyeyu-evropi/670380', 'Finnair назвали найбезпечнішою авіакомпанією Європи', 'Gazeta.ua - 2016-01-08 18:06:36', 'http://gazeta.ua/articles/life/_finnair-nazvali-najbezpechnishoyu-aviakompaniyeyu-evropi/670380', '/images/2016-01-09/1452331853_1537.jpg', 0, '2016-01-08 18:06:36', 0),
(3653, 3, 12, 'http://gazeta.ua/articles/np/_v-obse-kazhut-pro-vidnosnij-spokij-na-donbasi/670379', 'В ОБСЄ кажуть про відносний спокій на Донбасі', 'Gazeta.ua - 2016-01-08 17:48:15', 'http://gazeta.ua/articles/np/_v-obse-kazhut-pro-vidnosnij-spokij-na-donbasi/670379', '/images/2016-01-09/1452331853_219.jpg', 0, '2016-01-08 17:48:15', 0),
(3654, 3, 12, 'http://gazeta.ua/articles/regions/_v-enakiyevomu-bojoviki-nabirayut-najmanciv-na-vijnu-v-siriyi/670376', 'В Єнакієвому бойовики набирають найманців на війну в Сирії', 'Gazeta.ua - 2016-01-08 17:30:19', 'http://gazeta.ua/articles/regions/_v-enakiyevomu-bojoviki-nabirayut-najmanciv-na-vijnu-v-siriyi/670376', '/images/2016-01-09/1452331854_218.jpg', 0, '2016-01-08 17:30:19', 0),
(3655, 3, 12, 'http://gazeta.ua/articles/np/_na-rivnenschini-pid-kolesami-inomarki-zaginuv-policejskij/670378', 'На Рівненщині під колесами іномарки загинув поліцейський', 'Gazeta.ua - 2016-01-08 17:25:10', 'http://gazeta.ua/articles/np/_na-rivnenschini-pid-kolesami-inomarki-zaginuv-policejskij/670378', '/images/2016-01-09/1452331854_1139.jpg', 0, '2016-01-08 17:25:10', 0),
(3656, 3, 12, 'http://gazeta.ua/articles/sport/_luyisa-suaresa-diskvalifikuvali-na-dva-matchi/670377', 'Луїса Суареса дискваліфікували на два матчі', 'Gazeta.ua - 2016-01-08 17:21:34', 'http://gazeta.ua/articles/sport/_luyisa-suaresa-diskvalifikuvali-na-dva-matchi/670377', '/images/2016-01-09/1452331854_2005.jpg', 0, '2016-01-08 17:21:34', 0),
(3647, 3, 12, 'http://gazeta.ua/articles/politics/_final-aksonova-yak-i-vsih-zradnikiv-bude-sumnij-zhurnalist/670384', 'Фінал Аксьонова, як і всіх зрадників, буде сумний - журналіст', 'Gazeta.ua - 2016-01-08 19:32:02', 'http://gazeta.ua/articles/politics/_final-aksonova-yak-i-vsih-zradnikiv-bude-sumnij-zhurnalist/670384', '/images/2016-01-09/1452331851_699.jpg', 0, '2016-01-08 19:32:02', 0),
(3640, 3, 12, 'http://gazeta.ua/articles/culture/_harkivska-koza-pokolola-chernigivciv/670389', 'Харківська коза поколола чернігівців', 'Gazeta.ua - 2016-01-08 22:52:15', 'http://gazeta.ua/articles/culture/_harkivska-koza-pokolola-chernigivciv/670389', '/images/2016-01-09/1452331849_647.jpg', 0, '2016-01-08 22:52:15', 0),
(3641, 3, 12, 'http://gazeta.ua/articles/regions/_lvovom-projshla-tradicijna-hoda-zvizdariv/670393', 'Львовом пройшла традиційна Хода звіздарів', 'Gazeta.ua - 2016-01-08 22:42:32', 'http://gazeta.ua/articles/regions/_lvovom-projshla-tradicijna-hoda-zvizdariv/670393', '/images/2016-01-09/1452331849_1098.jpg', 0, '2016-01-08 22:42:32', 0),
(3642, 3, 12, 'http://gazeta.ua/articles/life/_v-egipti-obstrilyali-gotel-z-turistami/670392', 'В Єгипті обстріляли готель з туристами', 'Gazeta.ua - 2016-01-08 22:24:50', 'http://gazeta.ua/articles/life/_v-egipti-obstrilyali-gotel-z-turistami/670392', '/images/2016-01-09/1452331849_1886.jpg', 0, '2016-01-08 22:24:50', 0),
(3643, 3, 12, 'http://gazeta.ua/articles/regions/_v-okupovanomu-sevastopoli-vidklyuchatimut-svitlo-kozhni-tri-godini/670391', 'В окупованому Севастополі відключатимуть світло кожні три години', 'Gazeta.ua - 2016-01-08 21:52:27', 'http://gazeta.ua/articles/regions/_v-okupovanomu-sevastopoli-vidklyuchatimut-svitlo-kozhni-tri-godini/670391', '/images/2016-01-09/1452331850_1560.jpg', 0, '2016-01-08 21:52:27', 0),
(3644, 3, 12, 'http://gazeta.ua/articles/life/_golova-policiyi-kelna-podav-u-vidstavku-cherez-spravu-pro-napadi-na-zhinok/670390', 'Голова поліції Кельна подав у відставку через справу про напади на жінок', 'Gazeta.ua - 2016-01-08 21:34:28', 'http://gazeta.ua/articles/life/_golova-policiyi-kelna-podav-u-vidstavku-cherez-spravu-pro-napadi-na-zhinok/670390', '/images/2016-01-09/1452331850_1047.jpg', 0, '2016-01-08 21:34:28', 0),
(3645, 3, 12, 'http://gazeta.ua/articles/science/_brend-motorola-znikne-z-rinku/670388', 'Бренд Motorola зникне з ринку', 'Gazeta.ua - 2016-01-08 20:21:07', 'http://gazeta.ua/articles/science/_brend-motorola-znikne-z-rinku/670388', '/images/2016-01-09/1452331850_11.jpg', 0, '2016-01-08 20:21:07', 0),
(3646, 3, 12, 'http://gazeta.ua/articles/np/_vid-ranku-bojoviki-14-raziv-vidkrivali-vogon-po-ukrayinskih-poziciyah/670387', 'Від ранку бойовики 14 разів відкривали вогонь по українських позиціях', 'Gazeta.ua - 2016-01-08 19:53:54', 'http://gazeta.ua/articles/np/_vid-ranku-bojoviki-14-raziv-vidkrivali-vogon-po-ukrayinskih-poziciyah/670387', '/images/2016-01-09/1452331851_1465.jpg', 0, '2016-01-08 19:53:54', 0),
(3639, 3, 12, 'http://gazeta.ua/articles/politics/_ukrayina-maye-zaproponuvati-krimu-derzhavnu-avtonomiyu-kravchuk/670394', 'Україна має запропонувати Криму державну автономію - Кравчук', 'Gazeta.ua - 2016-01-08 22:56:56', 'http://gazeta.ua/articles/politics/_ukrayina-maye-zaproponuvati-krimu-derzhavnu-avtonomiyu-kravchuk/670394', '/images/2016-01-09/1452331848_873.jpg', 0, '2016-01-08 22:56:56', 0),
(3638, 3, 12, 'http://gazeta.ua/articles/politics/_stalo-vidomo-koli-rada-es-rozglyane-pitannya-nadannya-ukrayini-bezvizovogo-rezhimu/670395', 'Стало відомо, коли Рада ЄС розгляне питання надання Україні безвізового режиму', 'Gazeta.ua - 2016-01-08 23:45:27', 'http://gazeta.ua/articles/politics/_stalo-vidomo-koli-rada-es-rozglyane-pitannya-nadannya-ukrayini-bezvizovogo-rezhimu/670395', '/images/2016-01-09/1452331848_238.jpg', 0, '2016-01-08 23:45:27', 0),
(3637, 3, 12, 'http://gazeta.ua/articles/life/_policiya-egiptu-posilila-riven-bezpeki-na-vsih-kurortah-krayini/670397', 'Поліція Єгипту посилила рівень безпеки на всіх курортах країни', 'Gazeta.ua - 2016-01-09 00:23:09', 'http://gazeta.ua/articles/life/_policiya-egiptu-posilila-riven-bezpeki-na-vsih-kurortah-krayini/670397', '/images/2016-01-09/1452331848_39.jpg', 0, '2016-01-09 00:23:09', 0),
(3636, 3, 12, 'http://gazeta.ua/articles/life/_u-meksici-spijmali-znamenitogo-vtikacha-z-vyaznici-narkobarona-el-capo/670398', 'У Мексиці спіймали знаменитого втікача з в''язниці наркобарона "Ель Чапо"', 'Gazeta.ua - 2016-01-09 00:56:17', 'http://gazeta.ua/articles/life/_u-meksici-spijmali-znamenitogo-vtikacha-z-vyaznici-narkobarona-el-capo/670398', '/images/2016-01-09/1452331847_227.jpg', 0, '2016-01-09 00:56:17', 0),
(3635, 3, 12, 'http://gazeta.ua/articles/politics/_prezident-polschi-skasuvav-priznachennya-novogo-posla-v-ukrayini/670399', 'Президент Польщі скасував призначення нового посла в Україні', 'Gazeta.ua - 2016-01-09 01:33:26', 'http://gazeta.ua/articles/politics/_prezident-polschi-skasuvav-priznachennya-novogo-posla-v-ukrayini/670399', '/images/2016-01-09/1452331847_1221.jpg', 0, '2016-01-09 01:33:26', 0),
(3634, 3, 12, 'http://gazeta.ua/articles/economics/_kitaj-obmezhiv-prodazh-dolariv-financial-times/670400', 'Китай обмежив продаж доларів - Financial Times', 'Gazeta.ua - 2016-01-09 01:57:58', 'http://gazeta.ua/articles/economics/_kitaj-obmezhiv-prodazh-dolariv-financial-times/670400', '/images/2016-01-09/1452331846_1376.jpg', 0, '2016-01-09 01:57:58', 0),
(3633, 3, 12, 'http://gazeta.ua/articles/life/_u-siriyi-bojovik-idil-publichno-strativ-svoyu-matir/670401', 'У Сирії бойовик ІДІЛ публічно стратив свою матір', 'Gazeta.ua - 2016-01-09 02:34:30', 'http://gazeta.ua/articles/life/_u-siriyi-bojovik-idil-publichno-strativ-svoyu-matir/670401', '/images/2016-01-09/1452331846_930.jpg', 0, '2016-01-09 02:34:30', 0),
(3631, 3, 12, 'http://gazeta.ua/articles/economics/_zubko-2016-rik-stane-perelomnim-dlya-ekonomiki-ukrayini/670403', 'Зубко: 2016 рік стане переломним для економіки України', 'Gazeta.ua - 2016-01-09 03:38:27', 'http://gazeta.ua/articles/economics/_zubko-2016-rik-stane-perelomnim-dlya-ekonomiki-ukrayini/670403', '/images/2016-01-09/1452331846_148.jpg', 0, '2016-01-09 03:38:27', 0),
(3632, 3, 12, 'http://gazeta.ua/articles/np/_v-okupovanij-gorlivci-bojoviki-vlashtuvali-obshuk-misiyi-obse/670402', 'В окупованій Горлівці бойовики влаштували обшук місії ОБСЄ', 'Gazeta.ua - 2016-01-09 02:52:51', 'http://gazeta.ua/articles/np/_v-okupovanij-gorlivci-bojoviki-vlashtuvali-obshuk-misiyi-obse/670402', '/images/2016-01-09/1452331846_102.jpg', 0, '2016-01-09 02:52:51', 0),
(3630, 3, 12, 'http://gazeta.ua/articles/politics/_u-britaniyi-prorosijsku-partiyu-viklyuchili-z-reyestru/670404', 'У Британії проросійську партію виключили з реєстру', 'Gazeta.ua - 2016-01-09 03:50:59', 'http://gazeta.ua/articles/politics/_u-britaniyi-prorosijsku-partiyu-viklyuchili-z-reyestru/670404', '/images/2016-01-09/1452331845_1076.jpg', 0, '2016-01-09 03:50:59', 0),
(3629, 3, 12, 'http://gazeta.ua/articles/politics/_v-ukrayinu-yide-predstavnik-derzhdepu-ssa-z-kontrolyu-nad-ozbroyennyami/670405', 'В Україну їде представник Держдепу США з контролю над озброєннями', 'Gazeta.ua - 2016-01-09 04:17:47', 'http://gazeta.ua/articles/politics/_v-ukrayinu-yide-predstavnik-derzhdepu-ssa-z-kontrolyu-nad-ozbroyennyami/670405', '/images/2016-01-09/1452331845_808.jpg', 0, '2016-01-09 04:17:47', 0),
(3628, 3, 12, 'http://gazeta.ua/articles/life/_premyer-cehiyi-vistupiv-za-deportaciyu-z-es-migrantiv-za-zlochini/670406', 'Прем''єр Чехії виступив за депортацію з ЄС мігрантів за злочини', 'Gazeta.ua - 2016-01-09 05:20:24', 'http://gazeta.ua/articles/life/_premyer-cehiyi-vistupiv-za-deportaciyu-z-es-migrantiv-za-zlochini/670406', '/images/2016-01-09/1452331844_1596.jpg', 0, '2016-01-09 05:20:24', 0),
(3626, 3, 12, 'http://gazeta.ua/articles/yuliya-lipich/_zahisniki/669852', 'Захисники', 'Gazeta.ua - 2016-01-09 09:05:47', 'http://gazeta.ua/articles/yuliya-lipich/_zahisniki/669852', '/images/default.jpg', 0, '2016-01-09 09:05:47', 0),
(3627, 3, 12, 'http://gazeta.ua/articles/life/_piket-pid-mvs-i-vimogi-dlya-opoziciyi-9-sichnya/668837', 'Пікет під МВС і вимоги для опозиції (9 січня)', 'Gazeta.ua - 2016-01-09 08:00:01', 'http://gazeta.ua/articles/life/_piket-pid-mvs-i-vimogi-dlya-opoziciyi-9-sichnya/668837', '/images/2016-01-09/1452331844_237.jpg', 0, '2016-01-09 08:00:01', 0),
(3625, 3, 12, 'http://gazeta.ua/articles/life/_bojoviki-majzhe-30-raziv-obstrilyali-ukrayinski-poziciyi/670407', 'Бойовики майже 30 разів обстріляли українські позиції', 'Gazeta.ua - 2016-01-09 09:22:08', 'http://gazeta.ua/articles/life/_bojoviki-majzhe-30-raziv-obstrilyali-ukrayinski-poziciyi/670407', '/images/2016-01-09/1452331844_157.jpg', 0, '2016-01-09 09:22:08', 0),
(3620, 3, 12, 'http://gazeta.ua/articles/politics/_es-mozhe-zaprovaditi-bezvizovij-rezhim-dlya-ukrayinciv-uzhe-v-berezni/670412', 'ЄС може запровадити безвізовий режим для українців уже в березні', 'Gazeta.ua - 2016-01-09 11:25:45', 'http://gazeta.ua/articles/politics/_es-mozhe-zaprovaditi-bezvizovij-rezhim-dlya-ukrayinciv-uzhe-v-berezni/670412', '/images/2016-01-09/1452331842_804.jpg', 0, '2016-01-09 11:25:45', 0),
(3621, 3, 12, 'http://gazeta.ua/articles/politics/_cas-platiti-za-krim-ukrayina-podala-sotni-pozoviv-proti-rosiyi-zmi/670411', 'Час платити за Крим: Україна подала сотні позовів проти Росії - ЗМІ', 'Gazeta.ua - 2016-01-09 10:49:08', 'http://gazeta.ua/articles/politics/_cas-platiti-za-krim-ukrayina-podala-sotni-pozoviv-proti-rosiyi-zmi/670411', '/images/2016-01-09/1452331842_448.jpg', 0, '2016-01-09 10:49:08', 0),
(3622, 3, 12, 'http://gazeta.ua/articles/np/_cerez-negodu-bez-svitla-zalishayutsya-142-naselenih-punkti/670409', 'Через негоду без світла залишаються 142 населених пункти', 'Gazeta.ua - 2016-01-09 10:09:38', 'http://gazeta.ua/articles/np/_cerez-negodu-bez-svitla-zalishayutsya-142-naselenih-punkti/670409', '/images/2016-01-09/1452331843_1047.jpg', 0, '2016-01-09 10:09:38', 0),
(3623, 3, 12, 'http://gazeta.ua/articles/culture/_10-novih-serialiv-zimi-yaki-varto-podivitisya/670396', '10 нових серіалів зими, які варто подивитися', 'Gazeta.ua - 2016-01-09 10:05:53', 'http://gazeta.ua/articles/culture/_10-novih-serialiv-zimi-yaki-varto-podivitisya/670396', '/images/2016-01-09/1452331843_991.jpg', 0, '2016-01-09 10:05:53', 0),
(3624, 3, 12, 'http://gazeta.ua/articles/life/_sinoptiki-rozpovili-chogo-chekati-vid-pogodi-u-vihidni/670408', 'Синоптики розповіли, чого чекати від погоди у вихідні', 'Gazeta.ua - 2016-01-09 09:45:33', 'http://gazeta.ua/articles/life/_sinoptiki-rozpovili-chogo-chekati-vid-pogodi-u-vihidni/670408', '/images/2016-01-09/1452331843_1753.jpg', 0, '2016-01-09 09:45:33', 0),
(3710, 3, 13, 'http://tsn.ua/ato/boyoviki-rozpochali-nacionalizaciyu-kvartir-u-lugansku-568000.html', 'Бойовики розпочали "націоналізацію" квартир у Луганську', 'Новини на tsn.ua - 2016-01-08 20:09:53', 'http://tsn.ua/ato/boyoviki-rozpochali-nacionalizaciyu-kvartir-u-lugansku-568000.html', '/images/2016-01-09/1452333041_201.jpg', 0, '2016-01-08 20:09:53', 0),
(3709, 3, 13, 'http://tsn.ua/svit/u-yevrozoni-nazvali-kilkist-nepracyuyuchogo-naselennya-u-nimechchini-pracyuyut-naybilshe-567490.html', 'У Єврозоні назвали кількість безробітного населення: у Німеччині працюють найбільше. Інфографіка', 'Новини на tsn.ua - 2016-01-08 20:19:32', 'http://tsn.ua/svit/u-yevrozoni-nazvali-kilkist-nepracyuyuchogo-naselennya-u-nimechchini-pracyuyut-naybilshe-567490.html', '/images/2016-01-09/1452333041_1806.jpg', 0, '2016-01-08 20:19:32', 0),
(3707, 3, 13, 'http://tsn.ua/svit/u-meksici-upiymali-vidomogo-narkobarona-utikacha-568012.html', 'У Мексиці упіймали відомого наркобарона-утікача', 'Новини на tsn.ua - 2016-01-08 20:52:02', 'http://tsn.ua/svit/u-meksici-upiymali-vidomogo-narkobarona-utikacha-568012.html', '/images/2016-01-09/1452333040_1901.jpg', 0, '2016-01-08 20:52:02', 0),
(3708, 3, 13, 'http://tsn.ua/ato/u-gorlivci-ozbroyenni-boyoviki-obshukali-mashinu-obsye-pritisnuvshi-sposterigachiv-do-zemli-568006.html', 'У Горлівці озброєні бойовики обшукали машину ОБСЄ, притиснувши спостерігачів до землі', 'Новини на tsn.ua - 2016-01-08 20:36:17', 'http://tsn.ua/ato/u-gorlivci-ozbroyenni-boyoviki-obshukali-mashinu-obsye-pritisnuvshi-sposterigachiv-do-zemli-568006.html', '/images/2016-01-09/1452333041_678.jpg', 0, '2016-01-08 20:36:17', 0),
(3706, 3, 13, 'http://tsn.ua/svit/ukrayina-katastrofichno-vidstaye-vid-bilorusi-ta-rosiyi-za-kilkistyu-vidanih-knizhok-infografika-568015.html', 'Україна катастрофічно відстає від Білорусі та Росії за кількістю виданих книжок. Інфографіка', 'Новини на tsn.ua - 2016-01-08 21:20:29', 'http://tsn.ua/svit/ukrayina-katastrofichno-vidstaye-vid-bilorusi-ta-rosiyi-za-kilkistyu-vidanih-knizhok-infografika-568015.html', '/images/2016-01-09/1452333040_929.jpg', 0, '2016-01-08 21:20:29', 0),
(3704, 3, 13, 'http://tsn.ua/kyiv/sestra-luk-yanivskogo-v-yaznya-prorvalasya-do-morgu-na-liviy-ruci-u-zagiblogo-virizane-misce-de-buv-ukol-568021.html', 'Сестра Лук''янівського в''язня прорвалася до моргу: на лівій руці у загиблого вирізане місце, де був укол', 'Новини на tsn.ua - 2016-01-08 21:45:38', 'http://tsn.ua/kyiv/sestra-luk-yanivskogo-v-yaznya-prorvalasya-do-morgu-na-liviy-ruci-u-zagiblogo-virizane-misce-de-buv-ukol-568021.html', '/images/default.jpg', 0, '2016-01-08 21:45:38', 0),
(3705, 3, 13, 'http://tsn.ua/ato/boyoviki-rozmischuyut-gradi-i-tanki-v-rayoni-donecka-rozvidka-568018.html', 'Бойовики розміщують "Гради" і танки в районі Донецька - розвідка', 'Новини на tsn.ua - 2016-01-08 21:28:50', 'http://tsn.ua/ato/boyoviki-rozmischuyut-gradi-i-tanki-v-rayoni-donecka-rozvidka-568018.html', '/images/default.jpg', 0, '2016-01-08 21:28:50', 0),
(3703, 3, 13, 'http://tsn.ua/svit/u-yegipti-teroristi-z-praporami-id-vlashtuvali-strilyaninu-bilya-gotelyu-ye-poraneni-568030.html', 'У Єгипті терористи з прапорами "ІД" влаштували стрілянину біля готелю, є поранені', 'Новини на tsn.ua - 2016-01-08 22:01:58', 'http://tsn.ua/svit/u-yegipti-teroristi-z-praporami-id-vlashtuvali-strilyaninu-bilya-gotelyu-ye-poraneni-568030.html', '/images/2016-01-09/1452333040_1656.jpg', 0, '2016-01-08 22:01:58', 0),
(3702, 3, 13, 'http://tsn.ua/ukrayina/pozhezha-na-rizdvo-u-zaporizhzhi-troye-lyudey-zaginuli-v-ohopleniy-polum-yam-kvartiri-568027.html', 'Пожежа на Різдво: у Запоріжжі троє людей загинули в охопленій полум''ям квартирі', 'Новини на tsn.ua - 2016-01-08 22:11:04', 'http://tsn.ua/ukrayina/pozhezha-na-rizdvo-u-zaporizhzhi-troye-lyudey-zaginuli-v-ohopleniy-polum-yam-kvartiri-568027.html', '/images/default.jpg', 0, '2016-01-08 22:11:04', 0),
(3700, 3, 13, 'http://tsn.ua/kyiv/kiyiv-pohovalo-pid-snigom-poki-u-kmda-zvituvali-pro-aktivne-pribirannya-568039.html', 'Київ "поховало" під снігом, поки у КМДА звітували про активне прибирання', 'Новини на tsn.ua - 2016-01-08 22:59:20', 'http://tsn.ua/kyiv/kiyiv-pohovalo-pid-snigom-poki-u-kmda-zvituvali-pro-aktivne-pribirannya-568039.html', '/images/default.jpg', 0, '2016-01-08 22:59:20', 0),
(3701, 3, 13, 'http://tsn.ua/kyiv/ryatuvalniki-sprostuvali-informaciyu-pro-pozhezhu-v-stolichnomu-vishi-568036.html', 'Рятувальники спростували інформацію про пожежу в столичному виші', 'Новини на tsn.ua - 2016-01-08 22:50:54', 'http://tsn.ua/kyiv/ryatuvalniki-sprostuvali-informaciyu-pro-pozhezhu-v-stolichnomu-vishi-568036.html', '/images/2016-01-09/1452333039_395.jpg', 0, '2016-01-08 22:50:54', 0),
(3699, 3, 13, 'http://tsn.ua/politika/stalo-vidomo-koli-rada-yevropi-rozglyane-pitannya-pro-bezvizoviy-rezhim-iz-ukrayinoyu-568042.html', 'Стало відомо, коли Рада Європи розгляне питання про безвізовий режим із Україною', 'Новини на tsn.ua - 2016-01-08 23:02:24', 'http://tsn.ua/politika/stalo-vidomo-koli-rada-yevropi-rozglyane-pitannya-pro-bezvizoviy-rezhim-iz-ukrayinoyu-568042.html', '/images/2016-01-09/1452333039_1048.jpg', 0, '2016-01-08 23:02:24', 0),
(3698, 3, 13, 'http://tsn.ua/politika/kravchuk-dav-recept-yak-nabliziti-krim-do-ukrayini-568033.html', 'Кравчук дав рецепт, як наблизити Крим до України', 'Новини на tsn.ua - 2016-01-08 23:12:05', 'http://tsn.ua/politika/kravchuk-dav-recept-yak-nabliziti-krim-do-ukrayini-568033.html', '/images/2016-01-09/1452333039_723.jpg', 0, '2016-01-08 23:12:05', 0),
(3697, 3, 13, 'http://tsn.ua/ukrayina/pid-chas-rizdvyanih-svyat-na-zasnizhenih-dorogah-ukrayini-zaginuli-bilshe-desyatka-lyudey-infografika-568045.html', 'Під час різдвяних свят на засніжених дорогах України загинули більше десятка людей. Інфографіка', 'Новини на tsn.ua - 2016-01-08 23:40:08', 'http://tsn.ua/ukrayina/pid-chas-rizdvyanih-svyat-na-zasnizhenih-dorogah-ukrayini-zaginuli-bilshe-desyatka-lyudey-infografika-568045.html', '/images/2016-01-09/1452333039_999.jpg', 0, '2016-01-08 23:40:08', 0),
(3696, 3, 13, 'http://tsn.ua/ukrayina/u-harkovi-policiya-rozkrila-zbroyne-pograbuvannya-avtozapravki-u-novorichnu-nich-568048.html', 'У Харкові поліція розкрила збройне пограбування автозаправки у новорічну ніч', 'Новини на tsn.ua - 2016-01-09 00:12:10', 'http://tsn.ua/ukrayina/u-harkovi-policiya-rozkrila-zbroyne-pograbuvannya-avtozapravki-u-novorichnu-nich-568048.html', '/images/default.jpg', 0, '2016-01-09 00:12:10', 0),
(3695, 3, 13, 'http://tsn.ua/svit/u-yes-pidtverdili-priznachennya-ochilnika-policiyi-vilnyusa-golovoyu-konsultativnoyi-misiyi-v-ukrayini-568051.html', 'У ЄС підтвердили призначення очільника поліції Вільнюса головою Консультативної місії в Україні', 'Новини на tsn.ua - 2016-01-09 00:15:17', 'http://tsn.ua/svit/u-yes-pidtverdili-priznachennya-ochilnika-policiyi-vilnyusa-golovoyu-konsultativnoyi-misiyi-v-ukrayini-568051.html', '/images/2016-01-09/1452333038_219.jpg', 0, '2016-01-09 00:15:17', 0),
(3693, 3, 13, 'http://tsn.ua/kyiv/kiyanam-povernut-groshi-za-holodni-batareyi-pid-chas-lyutih-moroziv-568069.html', 'Киянам повернуть гроші за холодні батареї під час лютих морозів', 'Новини на tsn.ua - 2016-01-09 00:49:45', 'http://tsn.ua/kyiv/kiyanam-povernut-groshi-za-holodni-batareyi-pid-chas-lyutih-moroziv-568069.html', '/images/default.jpg', 0, '2016-01-09 00:49:45', 0),
(3694, 3, 13, 'http://tsn.ua/ukrayina/na-ternopilschini-petarda-vibuhnula-v-ruci-u-hlopchika-vidirvavshi-yomu-palci-568066.html', 'На Тернопільщині петарда вибухнула в руці у хлопчика, відірвавши йому пальці', 'Новини на tsn.ua - 2016-01-09 00:33:13', 'http://tsn.ua/ukrayina/na-ternopilschini-petarda-vibuhnula-v-ruci-u-hlopchika-vidirvavshi-yomu-palci-568066.html', '/images/default.jpg', 0, '2016-01-09 00:33:13', 0),
(3692, 3, 13, 'http://tsn.ua/ukrayina/osoblivo-nebezpechni-na-zaliznici-v-kolomiyi-vivisili-foto-vtikachiv-yanukovicha-i-ko-568072.html', 'Особливо небезпечні: на залізниці в Коломиї вивісили фото втікачів Януковича і Ко', 'Новини на tsn.ua - 2016-01-09 00:58:25', 'http://tsn.ua/ukrayina/osoblivo-nebezpechni-na-zaliznici-v-kolomiyi-vivisili-foto-vtikachiv-yanukovicha-i-ko-568072.html', '/images/2016-01-09/1452333038_1862.jpg', 0, '2016-01-09 00:58:25', 0),
(3691, 3, 13, 'http://tsn.ua/svit/kompaniyi-silikonovoyi-dolini-dopomozhut-ssha-borotisya-z-propagandoyu-islamskoyi-derzhavi-568075.html', 'Компанії Силіконової долини допоможуть США боротися з пропагандою "Ісламської держави"', 'Новини на tsn.ua - 2016-01-09 01:25:06', 'http://tsn.ua/svit/kompaniyi-silikonovoyi-dolini-dopomozhut-ssha-borotisya-z-propagandoyu-islamskoyi-derzhavi-568075.html', '/images/2016-01-09/1452333038_403.jpg', 0, '2016-01-09 01:25:06', 0),
(3690, 3, 13, 'http://tsn.ua/groshi/zubko-nazvav-osnovni-vikliki-dlya-rozvitku-ukrayinskoyi-ekonomiki-v-2016-roci-568078.html', 'Зубко назвав основні виклики для розвитку української економіки в 2016 році', 'Новини на tsn.ua - 2016-01-09 01:48:23', 'http://tsn.ua/groshi/zubko-nazvav-osnovni-vikliki-dlya-rozvitku-ukrayinskoyi-ekonomiki-v-2016-roci-568078.html', '/images/2016-01-09/1452333038_1913.jpg', 0, '2016-01-09 01:48:23', 0),
(3688, 3, 13, 'http://tsn.ua/svit/prezident-polschi-skasuvav-rishennya-pro-priznachennya-novogo-posla-v-ukrayini-568084.html', 'Президент Польщі скасував рішення про призначення нового посла в Україні', 'Новини на tsn.ua - 2016-01-09 02:48:56', 'http://tsn.ua/svit/prezident-polschi-skasuvav-rishennya-pro-priznachennya-novogo-posla-v-ukrayini-568084.html', '/images/2016-01-09/1452333037_1884.jpg', 0, '2016-01-09 02:48:56', 0),
(3689, 3, 13, 'http://tsn.ua/svit/u-yegipetskomu-mvs-oprilyudnili-oficiyni-podrobici-strilyanini-v-goteli-hurgadi-568081.html', 'У єгипетському МВС оприлюднили офіційні подробиці стрілянини в готелі Хургади', 'Новини на tsn.ua - 2016-01-09 02:19:31', 'http://tsn.ua/svit/u-yegipetskomu-mvs-oprilyudnili-oficiyni-podrobici-strilyanini-v-goteli-hurgadi-568081.html', '/images/2016-01-09/1452333037_465.jpg', 0, '2016-01-09 02:19:31', 0),
(3687, 3, 13, 'http://tsn.ua/dopomoga/yana-pavlyuk-potrebuye-dopomogi-403681.html', 'Яна Павлюк потребує допомоги', 'Новини на tsn.ua - 2016-01-09 03:24:33', 'http://tsn.ua/dopomoga/yana-pavlyuk-potrebuye-dopomogi-403681.html', '/images/2016-01-09/1452333037_1797.jpg', 0, '2016-01-09 03:24:33', 0),
(3686, 3, 13, 'http://tsn.ua/ato/boyoviki-obstrilyali-poziciyi-sil-ato-bilya-donecka-ta-gorlivki-568087.html', 'Бойовики обстріляли позиції сил АТО біля Донецька та Горлівки', 'Новини на tsn.ua - 2016-01-09 07:14:24', 'http://tsn.ua/ato/boyoviki-obstrilyali-poziciyi-sil-ato-bilya-donecka-ta-gorlivki-568087.html', '/images/2016-01-09/1452333037_1436.jpg', 0, '2016-01-09 07:14:24', 0),
(3685, 3, 13, 'http://tsn.ua/groshi/pershiy-povnocinniy-robochiy-tizhden-u-2016-roci-grivnya-pochne-iz-neznachnogo-zmicnennya-kursi-valyut-568090.html', 'Перший повноцінний робочий тиждень у 2016-му гривня розпочне із незначного зміцнення. Курси валют', 'Новини на tsn.ua - 2016-01-09 07:38:26', 'http://tsn.ua/groshi/pershiy-povnocinniy-robochiy-tizhden-u-2016-roci-grivnya-pochne-iz-neznachnogo-zmicnennya-kursi-valyut-568090.html', '/images/2016-01-09/1452333036_438.jpg', 0, '2016-01-09 07:38:26', 0),
(3683, 3, 13, 'http://tsn.ua/kyiv/kiyivskim-komunalnikam-skasuvali-vihidniy-i-zmusili-pribirati-snig-568096.html', 'Київським комунальникам скасували вихідний і змусили прибирати сніг', 'Новини на tsn.ua - 2016-01-09 08:27:14', 'http://tsn.ua/kyiv/kiyivskim-komunalnikam-skasuvali-vihidniy-i-zmusili-pribirati-snig-568096.html', '/images/2016-01-09/1452333036_1690.jpg', 0, '2016-01-09 08:27:14', 0),
(3684, 3, 13, 'http://tsn.ua/ukrayina/sinoptiki-poperedzhayut-pro-ozheledicyu-na-dorogah-ta-hurtovini-568093.html', 'Синоптики попереджають про ожеледицю на дорогах та сильні хуртовини', 'Новини на tsn.ua - 2016-01-09 07:59:06', 'http://tsn.ua/ukrayina/sinoptiki-poperedzhayut-pro-ozheledicyu-na-dorogah-ta-hurtovini-568093.html', '/images/2016-01-09/1452333036_1681.jpg', 0, '2016-01-09 07:59:06', 0),
(3682, 3, 13, 'http://tsn.ua/ukrayina/cherez-negodu-v-ukrayini-zalishayutsya-bez-svitla-mayzhe-pivtori-sotni-naselenih-punktiv-568099.html', 'Через негоду в Україні залишаються без світла майже півтори сотні населених пунктів', 'Новини на tsn.ua - 2016-01-09 09:05:10', 'http://tsn.ua/ukrayina/cherez-negodu-v-ukrayini-zalishayutsya-bez-svitla-mayzhe-pivtori-sotni-naselenih-punktiv-568099.html', '/images/2016-01-09/1452333036_1649.jpg', 0, '2016-01-09 09:05:10', 0),
(3681, 3, 13, 'http://tsn.ua/glamur/gnuchka-britni-spirs-u-rozhevih-shortah-i-topi-pokazala-yak-stoyit-vniz-golovoyu-568102.html', 'Гнучка Брітні Спірс у рожевих шортах і топі показала, як стоїть вниз головою', 'Новини на tsn.ua - 2016-01-09 09:09:09', 'http://tsn.ua/glamur/gnuchka-britni-spirs-u-rozhevih-shortah-i-topi-pokazala-yak-stoyit-vniz-golovoyu-568102.html', '/images/2016-01-09/1452333035_455.jpg', 0, '2016-01-09 09:09:09', 0),
(3680, 3, 13, 'http://tsn.ua/groshi/nafta-zdeshevshala-do-minimumiv-10-richnoyi-davnini-rosiyskiy-rubl-silno-prosiv-568105.html', 'Нафта здешевшала до мінімумів 10-річної давнини – російський рубль сильно "просів"', 'Новини на tsn.ua - 2016-01-09 09:39:57', 'http://tsn.ua/groshi/nafta-zdeshevshala-do-minimumiv-10-richnoyi-davnini-rosiyskiy-rubl-silno-prosiv-568105.html', '/images/2016-01-09/1452333035_813.jpg', 0, '2016-01-09 09:39:57', 0),
(3679, 3, 13, 'http://tsn.ua/glamur/moloda-mama-liv-tayler-vtretye-vagitna-568108.html', 'Молода мама Лів Тайлер втретє вагітна', 'Новини на tsn.ua - 2016-01-09 09:40:25', 'http://tsn.ua/glamur/moloda-mama-liv-tayler-vtretye-vagitna-568108.html', '/images/2016-01-09/1452333035_1910.jpg', 0, '2016-01-09 09:40:25', 0),
(3678, 3, 13, 'http://tsn.ua/politika/do-ukrayini-priyide-golovniy-amerikanskiy-kontroler-za-ozbroyennyam-568111.html', 'До України приїде головний американський контролер за озброєнням', 'Новини на tsn.ua - 2016-01-09 09:54:14', 'http://tsn.ua/politika/do-ukrayini-priyide-golovniy-amerikanskiy-kontroler-za-ozbroyennyam-568111.html', '/images/2016-01-09/1452333035_1606.jpg', 0, '2016-01-09 09:54:14', 0),
(3676, 3, 13, 'http://tsn.ua/foto/yaskrave-rizdvo-u-lvovi-centrom-mista-proyshla-hoda-zvizdariv-568117.html', 'Яскраве Різдво у Львові: центром міста пройшла хода звіздарів', 'Новини на tsn.ua - 2016-01-09 10:17:02', 'http://tsn.ua/foto/yaskrave-rizdvo-u-lvovi-centrom-mista-proyshla-hoda-zvizdariv-568117.html', '/images/2016-01-09/1452333034_1863.jpg', 0, '2016-01-09 10:17:02', 0),
(3677, 3, 13, 'http://tsn.ua/glamur/lizhnicya-olga-sumska-pozhalilasya-na-snoubordistiv-yaki-vluchali-yiy-u-bamper-568114.html', '"Лижниця" Ольга Сумська пожалілася на сноубордистів, які влучали їй у "бампер"', 'Новини на tsn.ua - 2016-01-09 10:09:24', 'http://tsn.ua/glamur/lizhnicya-olga-sumska-pozhalilasya-na-snoubordistiv-yaki-vluchali-yiy-u-bamper-568114.html', '/images/2016-01-09/1452333034_1839.jpg', 0, '2016-01-09 10:09:24', 0),
(3675, 3, 13, 'http://tsn.ua/ukrayina/v-uzhgorodi-vnochi-spalahnuv-gotel-568120.html', 'В Ужгороді вночі спалахнув готель', 'Новини на tsn.ua - 2016-01-09 10:35:49', 'http://tsn.ua/ukrayina/v-uzhgorodi-vnochi-spalahnuv-gotel-568120.html', '/images/2016-01-09/1452333034_1259.jpg', 0, '2016-01-09 10:35:49', 0),
(3674, 3, 13, 'http://tsn.ua/glamur/astaf-yeva-vlashtuvala-pikantnu-fotosesiyu-kolezi-z-nikita-568123.html', 'Астаф''єва влаштувала пікантну фотосесію колезі з NIKITA', 'Новини на tsn.ua - 2016-01-09 10:51:23', 'http://tsn.ua/glamur/astaf-yeva-vlashtuvala-pikantnu-fotosesiyu-kolezi-z-nikita-568123.html', '/images/2016-01-09/1452333034_1370.jpg', 0, '2016-01-09 10:51:23', 0),
(3672, 3, 13, 'http://tsn.ua/dopomoga/dopomozhit-bratikam-vovi-i-yuri-zdolati-nedugu-563281.html', 'Допоможіть братикам Вові і Юрі здолати недугу', 'Новини на tsn.ua - 2016-01-09 11:27:02', 'http://tsn.ua/dopomoga/dopomozhit-bratikam-vovi-i-yuri-zdolati-nedugu-563281.html', '/images/2016-01-09/1452333033_356.jpg', 0, '2016-01-09 11:27:02', 0),
(3673, 3, 13, 'http://tsn.ua/svit/u-rosiyi-likar-mesnik-odnim-udarom-ubiv-paciyenta-568132.html', 'У Росії лікар-месник одним ударом убив пацієнта', 'Новини на tsn.ua - 2016-01-09 11:20:29', 'http://tsn.ua/svit/u-rosiyi-likar-mesnik-odnim-udarom-ubiv-paciyenta-568132.html', '/images/2016-01-09/1452333033_871.jpg', 0, '2016-01-09 11:20:29', 0),
(3669, 3, 12, 'http://gazeta.ua/articles/life/_v-uzhgorodi-prodayut-chashki-slava-ukrayini-rosijskogo-virobnika/670365', 'В Ужгороді продають чашки "Слава Україні" російського виробника', 'Gazeta.ua - 2016-01-08 15:04:00', 'http://gazeta.ua/articles/life/_v-uzhgorodi-prodayut-chashki-slava-ukrayini-rosijskogo-virobnika/670365', '/images/2016-01-09/1452331859_1345.jpg', 0, '2016-01-08 15:04:00', 0),
(3670, 3, 12, 'http://gazeta.ua/articles/life/_pivnichna-koreya-pokazala-zapusk-balistichnoyi-raketi/670413', 'Північна Корея показала запуск балістичної ракети', 'Gazeta.ua - 2016-01-09 11:45:26', 'http://gazeta.ua/articles/life/_pivnichna-koreya-pokazala-zapusk-balistichnoyi-raketi/670413', '/images/2016-01-09/1452333029_2013.jpg', 0, '2016-01-09 11:45:26', 0),
(3671, 3, 13, 'http://tsn.ua/glamur/eks-druzhina-toma-kruza-zaruchilasya-iz-zirkoyu-strichki-dzhango-vilniy-zmi-568135.html', 'Екс-дружина Тома Круза заручилася із зіркою стрічки "Джанго вільний" - ЗМІ', 'Новини на tsn.ua - 2016-01-09 11:40:57', 'http://tsn.ua/glamur/eks-druzhina-toma-kruza-zaruchilasya-iz-zirkoyu-strichki-dzhango-vilniy-zmi-568135.html', '/images/2016-01-09/1452333033_1566.jpg', 0, '2016-01-09 11:40:57', 0),
(3668, 3, 12, 'http://gazeta.ua/articles/life/_niderlandi-provedut-kampaniyu-v-pidtrimku-ukrayini-pered-referendumom/670364', 'Нідерланди проведуть кампанію в підтримку України перед референдумом', 'Gazeta.ua - 2016-01-08 15:16:10', 'http://gazeta.ua/articles/life/_niderlandi-provedut-kampaniyu-v-pidtrimku-ukrayini-pered-referendumom/670364', '/images/2016-01-09/1452331859_1525.jpg', 0, '2016-01-08 15:16:10', 0),
(3667, 3, 12, 'http://gazeta.ua/articles/np/_na-kirovogradshini-v-palayuchomu-budinku-zaginula-babusya-iz-4richnoyu-vnuchkoyu/670366', 'На Кіровоградшині в палаючому будинку загинула бабуся із 4-річною внучкою', 'Gazeta.ua - 2016-01-08 15:17:12', 'http://gazeta.ua/articles/np/_na-kirovogradshini-v-palayuchomu-budinku-zaginula-babusya-iz-4richnoyu-vnuchkoyu/670366', '/images/2016-01-09/1452331859_1724.jpg', 0, '2016-01-08 15:17:12', 0),
(3666, 3, 12, 'http://gazeta.ua/articles/life/_u-rosiyi-zagorivsya-magistralnij-gazoprovid-u-turechchinu/670367', 'У Росії загорівся магістральний газопровід у Туреччину', 'Gazeta.ua - 2016-01-08 15:35:16', 'http://gazeta.ua/articles/life/_u-rosiyi-zagorivsya-magistralnij-gazoprovid-u-turechchinu/670367', '/images/2016-01-09/1452331858_169.jpg', 0, '2016-01-08 15:35:16', 0),
(3664, 3, 12, 'http://gazeta.ua/articles/life/_zamist-groshej-kolyadnikiv-nagorodzhuvali-pirizhkami-a-u-vertepi-hodili-tilki-hlopci-yak-u-lvovi-vidtvoryuyut-davni-tradiciyi/670369', 'Замість грошей колядників нагороджували пиріжками, а у вертепи ходили тільки хлопці - як у Львові відтворюють давні традиції', 'Gazeta.ua - 2016-01-08 16:19:22', 'http://gazeta.ua/articles/life/_zamist-groshej-kolyadnikiv-nagorodzhuvali-pirizhkami-a-u-vertepi-hodili-tilki-hlopci-yak-u-lvovi-vidtvoryuyut-davni-tradiciyi/670369', '/images/2016-01-09/1452331858_1809.jpg', 0, '2016-01-08 16:19:22', 0),
(3665, 3, 12, 'http://gazeta.ua/articles/np/_na-sumschini-spalili-avtivku-volonteru/670370', 'На Сумщині спалили автівку волонтеру', 'Gazeta.ua - 2016-01-08 16:16:24', 'http://gazeta.ua/articles/np/_na-sumschini-spalili-avtivku-volonteru/670370', '/images/2016-01-09/1452331858_502.jpg', 0, '2016-01-08 16:16:24', 0);

-- --------------------------------------------------------

--
-- Структура таблицы `rss_parser`
--
-- Создание: Янв 09 2016 г., 08:43
--

DROP TABLE IF EXISTS `rss_parser`;
CREATE TABLE `rss_parser` (
  `id` int(11) NOT NULL,
  `id_rss` int(11) NOT NULL,
  `link` varchar(255) NOT NULL,
  `period` int(11) NOT NULL,
  `update` int(11) NOT NULL,
  `title` varchar(225) NOT NULL,
  `description` varchar(225) NOT NULL,
  `mobile` text NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `rss_parser`
--

INSERT INTO `rss_parser` (`id`, `id_rss`, `link`, `period`, `update`, `title`, `description`, `mobile`, `date`) VALUES
(12, 3, 'http://gazeta.ua/rss', 0, 0, '', '', '?mobile=true', '0000-00-00 00:00:00'),
(13, 3, 'http://tsn.ua/rss', 0, 0, '', '', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Структура таблицы `special_item`
--
-- Создание: Дек 27 2015 г., 10:03
--

DROP TABLE IF EXISTS `special_item`;
CREATE TABLE `special_item` (
  `id` int(11) NOT NULL,
  `id_rss` int(11) NOT NULL,
  `id_spec` int(11) NOT NULL,
  `title` text NOT NULL,
  `link` text NOT NULL,
  `description` text NOT NULL,
  `img` text NOT NULL,
  `period` int(11) NOT NULL,
  `update` int(11) NOT NULL,
  `now` int(11) NOT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `special_item`
--

INSERT INTO `special_item` (`id`, `id_rss`, `id_spec`, `title`, `link`, `description`, `img`, `period`, `update`, `now`, `date`) VALUES
(22, 24010, 1451405206, 'test', 'dsgd', 'dfgd', '/images/2015-12-29/1451405181_adele.jpg', 0, 2, 0, '2015-12-29 22:35:25'),
(23, 24008, 1451405206, 'test', 'dsgd', 'dfgd', '/images/2015-12-29/1451405181_adele.jpg', 0, 2, 0, '2015-12-29 22:35:25');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Дек 14 2015 г., 11:16
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(25) NOT NULL,
  `hash_password` varchar(32) NOT NULL,
  `token` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `hash_password`, `token`) VALUES
(1, 'login', 'cb7b46ec74d6a42b4323648e212f5547', '123456');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `error_log`
--
ALTER TABLE `error_log`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `keywords`
--
ALTER TABLE `keywords`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_rss` (`id_rss`);

--
-- Индексы таблицы `rss`
--
ALTER TABLE `rss`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `rss_item`
--
ALTER TABLE `rss_item`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_rss_parser` (`id_rss_parser`),
  ADD KEY `id_rss` (`id_rss`);

--
-- Индексы таблицы `rss_parser`
--
ALTER TABLE `rss_parser`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_rss` (`id_rss`);

--
-- Индексы таблицы `special_item`
--
ALTER TABLE `special_item`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `error_log`
--
ALTER TABLE `error_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `keywords`
--
ALTER TABLE `keywords`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT для таблицы `rss`
--
ALTER TABLE `rss`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT для таблицы `rss_item`
--
ALTER TABLE `rss_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3711;
--
-- AUTO_INCREMENT для таблицы `rss_parser`
--
ALTER TABLE `rss_parser`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT для таблицы `special_item`
--
ALTER TABLE `special_item`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `keywords`
--
ALTER TABLE `keywords`
  ADD CONSTRAINT `keywords_ibfk_1` FOREIGN KEY (`id_rss`) REFERENCES `rss` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
